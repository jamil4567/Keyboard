# Bangla Keyboard - APK Build & Install Guide

## 🎯 সহজ উপায়ে আপনার ফোনে ইনস্টল করুন

---

## পদ্ধতি ১: Android Studio দিয়ে বিল্ড (সবচেয়ে সহজ) ✅

### Step 1: প্রয়োজনীয় জিনিস
- একটি কম্পিউটার (Windows/Mac/Linux)
- Android Studio (ফ্রি) - [Download করুন](https://developer.android.com/studio)
- ইন্টারনেট কানেকশন

### Step 2: Android Studio ইনস্টল করুন
1. উপরের লিংক থেকে Android Studio ডাউনলোড করুন
2. ইনস্টল করুন (Next → Next → Finish)
3. প্রথমবার ওপেন করলে কিছু ডাউনলোড হবে, অপেক্ষা করুন

### Step 3: প্রজেক্ট ওপেন করুন
1. আমি যে `BanglaKeyboard` ফোল্ডার দিয়েছি, সেটি কম্পিউটারে এক্সট্রাক্ট করুন
2. Android Studio ওপেন করুন
3. **"Open an existing project"** ক্লিক করুন
4. `BanglaKeyboard` ফোল্ডার সিলেক্ট করুন
5. Gradle sync করতে কিছু সময় লাগবে (5-10 মিনিট)

### Step 4: APK বিল্ড করুন
```
মেনুবার থেকে:
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

বা শর্টকাট:
- Windows: `Ctrl + F9`
- Mac: `Cmd + F9`

### Step 5: APK ফাইল খুঁজুন
বিল্ড শেষ হলে নিচের পথে APK পাবেন:
```
BanglaKeyboard/app/build/outputs/apk/debug/app-debug.apk
```

### Step 6: ফোনে ট্রান্সফার করুন
**উপায় A: USB দিয়ে**
1. ফোনকে USB দিয়ে কম্পিউটারে কানেক্ট করুন
2. `app-debug.apk` ফাইলটি ফোনের কোনো ফোল্ডারে কপি করুন

**উপায় B: Bluetooth দিয়ে**
1. কম্পিউটার থেকে ফোনে Bluetooth দিয়ে পাঠান

**উপায় C: Cloud দিয়ে**
1. Google Drive/ Dropbox এ আপলোড করুন
2. ফোন থেকে ডাউনলোড করুন

**উপায় D: Email/WhatsApp**
1. নিজের ইমেইলে পাঠান
2. ফোন থেকে ডাউনলোড করুন

### Step 7: ফোনে ইনস্টল করুন
1. ফোনের **Settings** → **Security** → **Unknown Sources** অন করুন
   (বা Settings → Apps → Special access → Install unknown apps)

2. File Manager দিয়ে APK ফাইলে যান

3. APK ফাইলে ট্যাপ করুন

4. **Install** বাটনে ক্লিক করুন

5. ইনস্টল শেষে **Open** ক্লিক করুন

---

## পদ্ধতি ২: Command Line দিয়ে বিল্ড (Advance) 💻

### Prerequisites
```bash
# Java JDK 17 ইনস্টল করুন
# Android SDK ইনস্টল করুন
# Environment Variables সেট করুন
```

### Build Commands
```bash
# প্রজেক্ট ফোল্ডারে যান
cd BanglaKeyboard

# Linux/Mac
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

### Output Location
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## পদ্ধতি ৩: Online Build Service ব্যবহার করুন 🌐

### GitHub + GitHub Actions
1. GitHub এ একটি রিপোজিটরি তৈরি করুন
2. এই প্রজেক্টের সব ফাইল আপলোড করুন
3. GitHub Actions workflow যোগ করুন
4. অটোমেটিক APK বিল্ড হবে

### Online APK Builder Websites
- [Buildozer](https://buildozer.io/)
- [Appetize.io](https://appetize.io/)

---

## 🔧 সমস্যা ও সমাধান

### সমস্যা ১: "Parse Error"
**কারণ:** APK করাপ্ট হয়েছে বা incomplete download
**সমাধান:** আবার ডাউনলোড/কপি করুন

### সমস্যা ২: "App not installed"
**কারণ:** আগের ভার্সন ইনস্টল থাকতে পারে
**সমাধান:**
```
Settings → Apps → Bangla Keyboard → Uninstall
then try again
```

### সমস্যা ৩: "Unknown Sources" অপশন পাচ্ছেন না
**Android 8+ এর জন্য:**
```
Settings → Apps → Special access → Install unknown apps
→ File Manager/Chrome → Allow from this source
```

### সমস্যা ৪: Gradle Sync Failed
**সমাধান:**
```
File → Invalidate Caches / Restart → Invalidate and Restart
```

---

## 📱 ফোনে কীভাবে কীবোর্ড সেটআপ করবেন

### Step 1: কীবোর্ড এনাবল করুন
1. অ্যাপ ওপেন করুন
2. **"Enable Keyboard"** বাটনে ক্লিক করুন
3. সিস্টেম সেটিংস খুলবে
4. **"Bangla Keyboard"** পাশের চেকবক্স টিক দিন
5. **OK** তে ক্লিক করুন

### Step 2: ডিফল্ট কীবোর্ড সিলেক্ট করুন
1. অ্যাপে ফিরে আসুন
2. **"Select Keyboard"** বাটনে ক্লিক করুন
3. **"Bangla Keyboard"** সিলেক্ট করুন

### Step 3: টেস্ট করুন
1. যেকোনো টেক্সট ফিল্ডে (WhatsApp, Messenger) ক্লিক করুন
2. কীবোর্ড ওপেন হবে
3. **স্পেসবারে বামে/ডানে সোয়াইপ** করে ভাষা পরিবর্তন করুন

---

## 🎮 ফিচার টেস্ট চেকলিস্ট

| ফিচার | কিভাবে টেস্ট করবেন |
|--------|-------------------|
| English Typing | ইংরেজি লিখুন |
| Bangla Typing | স্পেসবার সোয়াইপ করে বাংলা সিলেক্ট করুন |
| Avro Typing | অভ্র সিলেক্ট করে ফোনেটিক লিখুন |
| Language Switch | স্পেসবারে বামে/ডানে সোয়াইপ করুন |
| Emoji | 😊 বাটনে ক্লিক করুন |
| Clipboard | 📋 বাটনে ক্লিক করুন |
| Typing Sound | Settings → Sound On করুন |
| Vibration | Settings → Vibration On করুন |

---

## 📞 সাহায্য লাগলে

যদি কোনো সমস্যা হয়, আমাকে জানান:
1. কোন ধাপে সমস্যা হচ্ছে
2. কী এরর মেসেজ দেখাচ্ছে
3. আপনার Android ভার্সন কত

---

**Good Luck! 🎉**
