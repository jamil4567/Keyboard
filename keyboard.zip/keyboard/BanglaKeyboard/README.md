# Bangla Keyboard - Android IME

A feature-rich Android keyboard application supporting English, Bangla (বাংলা), and Avro (অভ্র) phonetic input methods.

## Features

### Language Support
- **English** - Standard QWERTY layout
- **Bangla (বাংলা)** - Direct Bangla Unicode input
- **Avro (অভ্র)** - Phonetic Bangla input

### Swipe Language Switch
- Swipe left/right on the spacebar to quickly switch between languages
- Visual indicator shows current language on spacebar

### Clipboard & Pinned Messages
- Clipboard history with up to 50 items
- Pin important messages for quick access
- Quick paste from clipboard bar above keyboard

### Emoji & GIF Support
- 1000+ emojis organized by categories
- Custom Bangla-themed emojis
- Exclusive new emoji combinations
- GIF support (coming soon)

### Typing Sounds
- 10 different sound sets:
  - Standard, Mechanical, Typewriter, Water Drop
  - Wood, Cherry, Ding, Pop, Click, Soft
- Adjustable volume
- On/Off toggle in settings

### Premium Features (20+)
1. Remove Ads
2. Premium Themes (50+ themes)
3. Custom Fonts (20+ fonts)
4. Gesture Typing
5. Cloud Sync
6. Advanced Clipboard (unlimited history)
7. Custom Sounds Pack
8. Animated Themes
9. Exclusive Emoji Pack 1
10. Exclusive Emoji Pack 2
11. Premium GIF Pack
12. Sticker Pack
13. Built-in Translator
14. Grammar Check
15. Advanced Voice Input
16. Smart Reply (AI-powered)
17. Text Shortcuts
18. Backup & Restore
19. Privacy Mode
20. Typing Statistics
21. ALL PREMIUM (Unlock everything)

### Settings
- Sound & Vibration controls
- Multiple themes (Auto, Light, Dark, Blue, Green, Purple, Pink)
- Font size adjustment
- Key height customization
- Auto-correction and predictions
- Double space for period
- Key preview popup
- Voice input
- Emoji predictions

## Technical Details

### Requirements
- Android 5.0 (API 21) or higher
- Internet connection for ads and some features

### Permissions
- `INTERNET` - For ads and cloud features
- `VIBRATE` - For haptic feedback
- `READ_CLIPBOARD` / `WRITE_CLIPBOARD` - Clipboard functionality
- `BILLING` - In-app purchases

### Architecture
- Language: Kotlin
- Min SDK: 21
- Target SDK: 34
- Architecture: MVVM pattern

## Building

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or later
- JDK 17 or later
- Android SDK 34

### Build Steps
1. Open project in Android Studio
2. Sync Gradle files
3. Build > Build Bundle(s) / APK(s) > Build APK(s)

### Play Store Upload
1. Generate signed bundle: Build > Generate Signed Bundle/APK
2. Select Android App Bundle
3. Create or select keystore
4. Upload to Google Play Console

## Configuration

### AdMob Setup
1. Create AdMob account
2. Add your app
3. Replace test ad unit IDs with your own in:
   - `AndroidManifest.xml`
   - `activity_main.xml`
   - `BanglaKeyboardService.kt`

### Firebase Setup
1. Create Firebase project
2. Add Android app
3. Download `google-services.json`
4. Place in `app/` directory

### In-App Purchases
1. Set up Google Play Console
2. Create in-app products with IDs matching `PremiumStoreActivity.kt`
3. Enable testing for license testing accounts

## License

This project is for educational purposes. Please respect intellectual property rights when using third-party assets.

## Credits

- Bangla Unicode mapping based on Bijoy and Unicode standards
- Avro phonetic algorithm inspired by avro.im
- Icons from Material Design

## Contact

For support or feature requests, please contact through the Play Store listing.

---

**Version:** 1.0.0  
**Developer:** Bangla Keyboard Team  
**Made with ❤️ for Bangla speakers worldwide**
