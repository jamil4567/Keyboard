# ProGuard rules for Bangla Keyboard
-keep class com.bangla.keyboard.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keep class com.android.billingclient.** { *; }
-dontwarn com.google.android.gms.ads.**
-dontwarn com.android.billingclient.**
