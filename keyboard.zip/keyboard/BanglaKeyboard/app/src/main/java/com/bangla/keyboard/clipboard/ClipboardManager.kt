package com.bangla.keyboard.clipboard

import android.content.ClipData
import android.content.ClipboardManager as AndroidClipboardManager
import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ClipboardManager(context: Context) {
    
    companion object {
        const val PREFS_NAME = "clipboard_prefs"
        const val KEY_HISTORY = "clipboard_history"
        const val KEY_PINNED = "pinned_items"
        const val MAX_HISTORY_SIZE = 50
    }
    
    private val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as AndroidClipboardManager
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    private var historyListener: android.content.ClipboardManager.OnPrimaryClipChangedListener? = null
    
    init {
        setupClipboardListener()
    }
    
    private fun setupClipboardListener() {
        historyListener = AndroidClipboardManager.OnPrimaryClipChangedListener {
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                val text = clip.getItemAt(0).text?.toString()
                text?.let { addToHistory(it) }
            }
        }
        clipboard.addPrimaryClipChangedListener(historyListener)
    }
    
    fun getClipboardHistory(): List<String> {
        val json = prefs.getString(KEY_HISTORY, "[]") ?: "[]"
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }
    
    fun getPinnedItems(): List<String> {
        val json = prefs.getString(KEY_PINNED, "[]") ?: "[]"
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }
    
    fun addToHistory(text: String) {
        if (text.isBlank()) return
        
        val history = getClipboardHistory().toMutableList()
        
        // Remove if already exists
        history.remove(text)
        
        // Add to front
        history.add(0, text)
        
        // Trim to max size
        while (history.size > MAX_HISTORY_SIZE) {
            history.removeAt(history.size - 1)
        }
        
        saveHistory(history)
    }
    
    fun pinItem(text: String) {
        val pinned = getPinnedItems().toMutableList()
        if (!pinned.contains(text)) {
            pinned.add(0, text)
            savePinned(pinned)
        }
    }
    
    fun unpinItem(text: String) {
        val pinned = getPinnedItems().toMutableList()
        pinned.remove(text)
        savePinned(pinned)
    }
    
    fun removeFromHistory(text: String) {
        val history = getClipboardHistory().toMutableList()
        history.remove(text)
        saveHistory(history)
    }
    
    fun clearHistory() {
        saveHistory(emptyList())
    }
    
    fun clearPinned() {
        savePinned(emptyList())
    }
    
    fun copyToClipboard(text: String) {
        val clip = ClipData.newPlainText("Copied Text", text)
        clipboard.setPrimaryClip(clip)
    }
    
    fun getPrimaryClip(): String? {
        return clipboard.primaryClip?.getItemAt(0)?.text?.toString()
    }
    
    fun hasPrimaryClip(): Boolean {
        return clipboard.hasPrimaryClip()
    }
    
    fun searchHistory(query: String): List<String> {
        return getClipboardHistory().filter { it.contains(query, ignoreCase = true) }
    }
    
    private fun saveHistory(history: List<String>) {
        prefs.edit().putString(KEY_HISTORY, gson.toJson(history)).apply()
    }
    
    private fun savePinned(pinned: List<String>) {
        prefs.edit().putString(KEY_PINNED, gson.toJson(pinned)).apply()
    }
    
    fun cleanup() {
        historyListener?.let {
            clipboard.removePrimaryClipChangedListener(it)
        }
    }
}
