package com.bangla.keyboard.emoji

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bangla.keyboard.R

class EmojiManager(private val context: Context) {
    
    private val recentEmojis = mutableListOf<String>()
    private val customEmojis = loadCustomEmojis()
    
    // All emoji categories
    private val emojiCategories = mapOf(
        "Recent" to recentEmojis,
        "Smileys" to EMOJI_SMILEYS,
        "People" to EMOJI_PEOPLE,
        "Animals" to EMOJI_ANIMALS,
        "Food" to EMOJI_FOOD,
        "Activities" to EMOJI_ACTIVITIES,
        "Travel" to EMOJI_TRAVEL,
        "Objects" to EMOJI_OBJECTS,
        "Symbols" to EMOJI_SYMBOLS,
        "Flags" to EMOJI_FLAGS,
        "Bangla" to EMOJI_BANGLA_CUSTOM,
        "New" to EMOJI_NEW_EXCLUSIVE
    )
    
    fun getEmojiView(context: Context, onEmojiClick: (String) -> Unit): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        
        // Category tabs
        val tabLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        
        val emojiGridContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        
        var currentGrid: GridLayout? = null
        
        emojiCategories.forEach { (category, emojis) ->
            // Create tab button
            val tabButton = TextView(context).apply {
                text = category
                setPadding(20, 10, 20, 10)
                setBackgroundResource(R.drawable.bg_tab_unselected)
                setOnClickListener {
                    // Update tab selection
                    tabLayout.children.forEach { child ->
                        (child as TextView).setBackgroundResource(R.drawable.bg_tab_unselected)
                    }
                    setBackgroundResource(R.drawable.bg_tab_selected)
                    
                    // Show emoji grid
                    currentGrid?.let { emojiGridContainer.removeView(it) }
                    currentGrid = createEmojiGrid(context, emojis, onEmojiClick)
                    emojiGridContainer.addView(currentGrid)
                }
            }
            tabLayout.addView(tabButton)
        }
        
        container.addView(tabLayout)
        
        // Add scrollable emoji area
        val scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            addView(emojiGridContainer)
        }
        
        container.addView(scrollView)
        
        // Show first category by default
        if (emojiCategories.isNotEmpty()) {
            currentGrid = createEmojiGrid(context, emojiCategories.values.first(), onEmojiClick)
            emojiGridContainer.addView(currentGrid)
        }
        
        return container
    }
    
    private fun createEmojiGrid(
        context: Context,
        emojis: List<String>,
        onEmojiClick: (String) -> Unit
    ): GridLayout {
        return GridLayout(context).apply {
            columnCount = 8
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            
            emojis.forEach { emoji ->
                val button = TextView(context).apply {
                    text = emoji
                    textSize = 24f
                    setPadding(10, 10, 10, 10)
                    gravity = android.view.Gravity.CENTER
                    setOnClickListener {
                        onEmojiClick(emoji)
                        addToRecent(emoji)
                    }
                }
                addView(button)
            }
        }
    }
    
    private fun addToRecent(emoji: String) {
        recentEmojis.remove(emoji)
        recentEmojis.add(0, emoji)
        if (recentEmojis.size > 30) {
            recentEmojis.removeAt(recentEmojis.size - 1)
        }
        saveRecentEmojis()
    }
    
    private fun saveRecentEmojis() {
        val prefs = context.getSharedPreferences("emoji_prefs", Context.MODE_PRIVATE)
        prefs.edit().putStringSet("recent_emojis", recentEmojis.toSet()).apply()
    }
    
    private fun loadCustomEmojis(): List<String> {
        return EMOJI_NEW_EXCLUSIVE
    }
    
    fun getAllEmojis(): List<String> {
        return emojiCategories.values.flatten()
    }
    
    fun searchEmojis(query: String): List<String> {
        return getAllEmojis().filter { it.contains(query, ignoreCase = true) }
    }
    
    // Emoji data
    companion object {
        val EMOJI_SMILEYS = listOf(
            "😀", "😃", "😄", "😁", "😅", "😂", "🤣", "😊", "😇", "🙂",
            "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋",
            "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥸", "🤩",
            "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣",
            "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬",
            "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗",
            "🤔", "🤭", "🤫", "🤥", "😶", "😐", "😑", "😬", "🙄", "😯",
            "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪", "😵", "🤐",
            "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈"
        )
        
        val EMOJI_PEOPLE = listOf(
            "👶", "👧", "🧒", "👦", "👩", "🧑", "👨", "👩‍🦱", "🧑‍🦱", "👨‍🦱",
            "👩‍🦰", "🧑‍🦰", "👨‍🦰", "👱‍♀️", "👱", "👱‍♂️", "👩‍🦳", "🧑‍🦳", "👨‍🦳", "👩‍🦲",
            "🧑‍🦲", "👨‍🦲", "🧔", "👵", "🧓", "👴", "👲", "👳‍♀️", "👳", "👳‍♂️",
            "🧕", "👮‍♀️", "👮", "👮‍♂️", "👷‍♀️", "👷", "👷‍♂️", "💂‍♀️", "💂", "💂‍♂️",
            "🕵️‍♀️", "🕵️", "🕵️‍♂️", "👩‍⚕️", "🧑‍⚕️", "👨‍⚕️", "👩‍🌾", "🧑‍🌾", "👨‍🌾", "👩‍🍳",
            "🧑‍🍳", "👨‍🍳", "👩‍🎓", "🧑‍🎓", "👨‍🎓", "👩‍🎤", "🧑‍🎤", "👨‍🎤", "👩‍🏫", "🧑‍🏫"
        )
        
        val EMOJI_ANIMALS = listOf(
            "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯",
            "🦁", "🐮", "🐷", "🐽", "🐸", "🐵", "🙈", "🙉", "🙊", "🐒",
            "🐔", "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇",
            "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜",
            "🦟", "🦗", "🕷", "🕸", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕",
            "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳"
        )
        
        val EMOJI_FOOD = listOf(
            "🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐",
            "🍈", "🍒", "🍑", "🍍", "🥝", "🥥", "🥑", "🍆", "🥔", "🥕",
            "🌽", "🌶", "🫑", "🥒", "🥬", "🥦", "🧄", "🧅", "🍄", "🥜",
            "🌰", "🍞", "🥐", "🥖", "🥨", "🥯", "🥞", "🧇", "🧀", "🍖",
            "🍗", "🥩", "🥓", "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🌯"
        )
        
        val EMOJI_ACTIVITIES = listOf(
            "⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱",
            "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🥅", "⛳", "🪁",
            "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛼", "🛷", "⛸",
            "🥌", "🎿", "⛷", "🏂", "🪂", "🏋️‍♀️", "🏋️", "🏋️‍♂️", "🤼‍♀️", "🤼"
        )
        
        val EMOJI_TRAVEL = listOf(
            "🚗", "🚕", "🚙", "🚌", "🚎", "🏎", "🚓", "🚑", "🚒", "🚐",
            "🛻", "🚚", "🚛", "🚜", "🦯", "🦽", "🦼", "🛴", "🚲", "🛵",
            "🏍", "🛺", "🚨", "🚔", "🚍", "🚘", "🚖", "🚡", "🚠", "🚟",
            "🚃", "🚋", "🚞", "🚝", "🚄", "🚅", "🚈", "🚂", "🚆", "🚇"
        )
        
        val EMOJI_OBJECTS = listOf(
            "⌚", "📱", "📲", "💻", "⌨️", "🖥", "🖨", "🖱", "🖲", "🕹",
            "🗜", "💽", "💾", "💿", "📀", "📼", "📷", "📸", "📹", "🎥",
            "📽", "🎞", "📞", "☎️", "📟", "📠", "📺", "📻", "🎙", "🎚",
            "🎛", "🧭", "⏱", "⏲", "⏰", "🕰", "⌛", "⏳", "📡", "🔋"
        )
        
        val EMOJI_SYMBOLS = listOf(
            "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔",
            "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️",
            "✝️", "☪️", "🕉", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐",
            "⛎", "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐"
        )
        
        val EMOJI_FLAGS = listOf(
            "🏳️", "🏴", "🏴‍☠️", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🇺🇳", "🇦🇫", "🇦🇽",
            "🇦🇱", "🇩🇿", "🇦🇸", "🇦🇩", "🇦🇴", "🇦🇮", "🇦🇶", "🇦🇬", "🇦🇷", "🇦🇲",
            "🇦🇼", "🇦🇺", "🇦🇹", "🇦🇿", "🇧🇸", "🇧🇭", "🇧🇩", "🇧🇧", "🇧🇾", "🇧🇪",
            "🇧🇿", "🇧🇯", "🇧🇲", "🇧🇹", "🇧🇴", "🇧🇦", "🇧🇼", "🇧🇷", "🇮🇴", "🇻🇬"
        )
        
        // Custom Bangla-themed emojis
        val EMOJI_BANGLA_CUSTOM = listOf(
            "🌾", "🍚", "🐟", "🥭", "🍌", "🍍", "🥥", "🍵", "☕", "🌶",
            "🎋", "🪷", "🌺", "🌸", "🪔", "🎪", "🎭", "🎨", "🎵", "🎶",
            "🪕", "🥁", "🎺", "🐅", "🐘", "🦚", "🦜", "🐊", "🐍", "🦎",
            "🌳", "🌴", "🌧", "⛈", "🌈", "☀️", "🌙", "⭐", "✨", "💫"
        )
        
        // Exclusive new emojis (custom combinations)
        val EMOJI_NEW_EXCLUSIVE = listOf(
            "🥰✨", "😍🔥", "🤩💫", "😎👑", "🤗💖", "😘💋", "🥳🎉", "😂👏",
            "🤣💯", "😊🌸", "😇✨", "🙂💕", "😉😏", "😌💆", "😋🍕", "😛👅",
            "😜🤪", "😝💦", "🤑💰", "🤠🤠", "😎😎", "🤓📚", "🧐🔍", "🤯🤯",
            "😳😳", "🥵🔥", "🥶❄️", "😱😱", "😨😰", "😥😓", "🤗🤗", "🤔💭",
            "🤭🤫", "🤥🤥", "😶😶", "😐😐", "😬😬", "🙄🙄", "😯😦", "😧😮",
            "😲😲", "🥱😴", "😴💤", "🤤🤤", "😪😵", "🤐🤐", "🥴🥴", "🤢🤮"
        )
    }
}

// Extension for ViewGroup children
inline val ViewGroup.children: Sequence<View>
    get() = (0 until childCount).asSequence().map { getChildAt(it) }
