package com.bangla.keyboard.ime

/**
 * Avro Phonetic Converter
 * Converts English phonetic input to Bangla Unicode
 */
class AvroConverter {
    
    private val phoneticMap = mapOf(
        // Vowels
        "a" to "অ",
        "aa" to "আ",
        "i" to "ই",
        "ii" to "ঈ",
        "u" to "উ",
        "uu" to "ঊ",
        "rri" to "ঋ",
        "e" to "এ",
        "oi" to "ঐ",
        "o" to "ও",
        "ou" to "ঔ",
        
        // Consonants
        "k" to "ক",
        "kh" to "খ",
        "g" to "গ",
        "gh" to "ঘ",
        "ng" to "ঙ",
        "c" to "চ",
        "ch" to "ছ",
        "j" to "জ",
        "jh" to "ঝ",
        "ny" to "ঞ",
        "tt" to "ট",
        "tth" to "ঠ",
        "dd" to "ড",
        "ddh" to "ঢ",
        "nn" to "ণ",
        "t" to "ত",
        "th" to "থ",
        "d" to "দ",
        "dh" to "ধ",
        "n" to "ন",
        "p" to "প",
        "ph" to "ফ",
        "f" to "ফ",
        "b" to "ব",
        "bh" to "ভ",
        "v" to "ভ",
        "m" to "ম",
        "z" to "য",
        "r" to "র",
        "l" to "ল",
        "sh" to "শ",
        "ss" to "ষ",
        "s" to "স",
        "h" to "হ",
        "rr" to "ড়",
        "rh" to "ঢ়",
        "y" to "য়",
        "kk" to "ক্ক",
        "kt" to "ক্ত",
        "kb" to "ক্ব",
        "km" to "ক্ম",
        "ky" to "ক্য",
        "kr" to "ক্র",
        "kl" to "ক্ল",
        "ksh" to "ক্ষ",
        "kkh" to "ক্ষ্ণ",
        "gg" to "জ্ঞ",
        "ghn" to "ঘ্ন",
        "cch" to "চ্ছ",
        "jj" to "জ্জ",
        "jjh" to "জ্ঝ",
        "jn" to "জ্ঞ",
        "ny" to "ঞ",
        "ttb" to "ট্ট",
        "dbh" to "দ্ভ",
        "ddr" to "দ্দ্র",
        "nch" to "ঞ্ছ",
        "nj" to "ঞ্জ",
        "nth" to "ন্থ",
        "nd" to "ন্দ",
        "ndr" to "ন্দ্র",
        "nn" to "ন্ন",
        "nm" to "ন্ম",
        "ns" to "ন্স",
        "pt" to "প্ত",
        "pn" to "প্ন",
        "pp" to "প্প",
        "py" to "প্য",
        "pr" to "প্র",
        "pl" to "প্ল",
        "ps" to "প্স",
        "phr" to "ফ্র",
        "bj" to "ব্জ",
        "bd" to "ব্দ",
        "bb" to "ব্ব",
        "by" to "ব্য",
        "br" to "ব্র",
        "bl" to "ব্ল",
        "bhr" to "ভ্র",
        "mn" to "ম্ন",
        "mp" to "ম্প",
        "mph" to "ম্ফ",
        "mb" to "ম্ব",
        "mbh" to "ম্ভ",
        "mm" to "ম্ম",
        "my" to "ম্য",
        "mr" to "ম্র",
        "ml" to "ম্ল",
        "lk" to "ল্ক",
        "lg" to "ল্গ",
        "lp" to "ল্প",
        "lb" to "ল্ব",
        "lm" to "ল্ম",
        "ly" to "ল্য",
        "ll" to "ল্ল",
        "shc" to "শ্চ",
        "shn" to "শ্ন",
        "shb" to "শ্ব",
        "shm" to "শ্ম",
        "shy" to "শ্য",
        "shr" to "শ্র",
        "shl" to "শ্ল",
        "sn" to "স্ন",
        "sp" to "স্প",
        "sf" to "স্ফ",
        "sb" to "স্ব",
        "sm" to "স্ম",
        "sy" to "স্য",
        "sr" to "স্র",
        "sl" to "স্ল",
        "hn" to "হ্ন",
        "hb" to "হ্ব",
        "hm" to "হ্ম",
        "hy" to "হ্য",
        "hr" to "হ্র",
        "hl" to "হ্ল",
        
        // Numbers
        "0" to "০",
        "1" to "১",
        "2" to "২",
        "3" to "৩",
        "4" to "৪",
        "5" to "৫",
        "6" to "৬",
        "7" to "৭",
        "8" to "৮",
        "9" to "৯",
        
        // Special characters
        "." to "।",
        ".." to ".",
        "$" to "৳"
    )
    
    private val vowelSigns = mapOf(
        "a" to "",
        "aa" to "া",
        "i" to "ি",
        "ii" to "ী",
        "u" to "ু",
        "uu" to "ূ",
        "rri" to "ৃ",
        "e" to "ে",
        "oi" to "ৈ",
        "o" to "ো",
        "ou" to "ৌ"
    )
    
    private val karForms = setOf('ি', 'ী', 'ু', 'ূ', 'ৃ', 'ে', 'ৈ', 'ো', 'ৌ')

    fun convert(input: String): String {
        if (input.isEmpty()) return input
        
        val result = StringBuilder()
        var i = 0
        
        while (i < input.length) {
            // Try to match longest possible pattern
            var matched = false
            var maxLen = minOf(5, input.length - i)
            
            while (maxLen > 0 && !matched) {
                val substring = input.substring(i, i + maxLen).lowercase()
                
                // Check for phonetic match
                if (phoneticMap.containsKey(substring)) {
                    result.append(phoneticMap[substring])
                    i += maxLen
                    matched = true
                    break
                }
                
                maxLen--
            }
            
            if (!matched) {
                result.append(input[i])
                i++
            }
        }
        
        return result.toString()
    }
    
    fun convertWord(word: String): String {
        return convert(word)
    }
    
    fun isVowel(char: Char): Boolean {
        return char in "aeiouAEIOU"
    }
    
    fun getVowelSign(vowel: String): String {
        return vowelSigns[vowel.lowercase()] ?: ""
    }
}
