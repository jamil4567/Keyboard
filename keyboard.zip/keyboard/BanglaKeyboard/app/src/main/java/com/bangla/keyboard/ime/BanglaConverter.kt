package com.bangla.keyboard.ime

/**
 * Direct Bangla Unicode Converter
 * Maps English keys to Bangla characters
 */
object BanglaConverter {
    
    private val directMap = mapOf(
        // Vowels
        'a' to "অ",
        'A' to "আ",
        'i' to "ই",
        'I' to "ঈ",
        'u' to "উ",
        'U' to "ঊ",
        'e' to "এ",
        'E' to "ঐ",
        'o' to "ও",
        'O' to "ঔ",
        
        // Consonants
        'k' to "ক",
        'K' to "খ",
        'g' to "গ",
        'G' to "ঘ",
        'N' to "ঙ",
        'c' to "চ",
        'C' to "ছ",
        'j' to "জ",
        'J' to "ঝ",
        'Y' to "ঞ",
        't' to "ত",
        'T' to "থ",
        'd' to "দ",
        'D' to "ধ",
        'n' to "ন",
        'p' to "প",
        'P' to "ফ",
        'b' to "ব",
        'B' to "ভ",
        'm' to "ম",
        'y' to "য",
        'r' to "র",
        'l' to "ল",
        'w' to "শ",
        'W' to "ষ",
        's' to "স",
        'h' to "হ",
        'R' to "ড়",
        'H' to "ঢ়",
        'v' to "য়",
        'x' to "ক্ষ",
        'X' to "জ্ঞ",
        'L' to "ল",
        'M' to "ম",
        'V' to "ভ",
        'z' to "য",
        'Z' to "জ্ঞ",
        
        // Numbers
        '0' to "০",
        '1' to "১",
        '2' to "২",
        '3' to "৩",
        '4' to "৪",
        '5' to "৫",
        '6' to "৬",
        '7' to "৭",
        '8' to "৮",
        '9' to "৯",
        
        // Special characters
        '.' to "।",
        ',' to ",",
        '?' to "?",
        '!' to "!",
        ':' to ":",
        ';' to ";",
        '"' to "\"",
        '\'' to "'",
        '(' to "(",
        ')' to ")",
        '[' to "[",
        ']' to "]",
        '{' to "{",
        '}' to "}",
        '+' to "+",
        '-' to "-",
        '*' to "×",
        '/' to "÷",
        '=' to "=",
        '%' to "%",
        '&' to "&",
        '|' to "|",
        '<' to "<",
        '>' to ">",
        '^' to "^",
        '~' to "~",
        '`' to "`",
        '@' to "@",
        '#' to "#",
        '$' to "৳",
        '_' to "_",
        ' ' to " ",
        '\n' to "\n",
        '\t' to "\t"
    )
    
    private val vowelSigns = mapOf(
        'a' to "",
        'A' to "া",
        'i' to "ি",
        'I' to "ী",
        'u' to "ু",
        'U' to "ূ",
        'e' to "ে",
        'E' to "ৈ",
        'o' to "ো",
        'O' to "ৌ"
    )
    
    fun englishToBangla(char: Char): String {
        return directMap[char] ?: char.toString()
    }
    
    fun englishToBangla(text: String): String {
        val result = StringBuilder()
        for (char in text) {
            result.append(englishToBangla(char))
        }
        return result.toString()
    }
    
    fun getVowelSign(char: Char): String {
        return vowelSigns[char] ?: ""
    }
    
    fun isBanglaConsonant(char: Char): Boolean {
        return char in 'ক'..'হ' || char in 'ড়'..'য়'
    }
    
    fun isBanglaVowel(char: Char): Boolean {
        return char in 'অ'..'ঔ' || char in 'া'..'ৌ' || char == '্'
    }
    
    fun addHasanta(consonant: String): String {
        return consonant + "্"
    }
    
    fun combineConsonants(first: String, second: String): String {
        return first + "্" + second
    }
}
