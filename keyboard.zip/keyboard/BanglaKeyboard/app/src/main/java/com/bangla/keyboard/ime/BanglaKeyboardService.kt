package com.bangla.keyboard.ime

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.media.AudioManager
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.GestureDetectorCompat
import com.bangla.keyboard.R
import com.bangla.keyboard.clipboard.ClipboardManager
import com.bangla.keyboard.emoji.EmojiManager
import com.bangla.keyboard.settings.SettingsManager
import com.bangla.keyboard.sound.SoundManager
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class BanglaKeyboardService : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    companion object {
        const val TAG = "BanglaKeyboardService"
        const val LANGUAGE_ENGLISH = 0
        const val LANGUAGE_BANGLA = 1
        const val LANGUAGE_AVRO = 2
        const val KEYCODE_LANGUAGE_SWITCH = -101
        const val KEYCODE_EMOJI = -102
        const val KEYCODE_CLIPBOARD = -103
        const val KEYCODE_GIF = -104
        const val KEYCODE_SETTINGS = -105
        const val KEYCODE_SPACE_SWIPE_LEFT = -106
        const val KEYCODE_SPACE_SWIPE_RIGHT = -107
        const val KEYCODE_PIN = -108
        const val KEYCODE_DELETE_WORD = -109
        const val KEYCODE_VOICE = -110
    }

    private lateinit var keyboardView: CustomKeyboardView
    private lateinit var candidateView: LinearLayout
    private lateinit var clipboardBar: LinearLayout
    private lateinit var emojiPanel: FrameLayout
    private lateinit var adContainer: FrameLayout
    
    private var englishKeyboard: Keyboard? = null
    private var englishShiftedKeyboard: Keyboard? = null
    private var banglaKeyboard: Keyboard? = null
    private var banglaShiftedKeyboard: Keyboard? = null
    private var avroKeyboard: Keyboard? = null
    private var symbolsKeyboard: Keyboard? = null
    private var symbolsShiftedKeyboard: Keyboard? = null
    private var numericKeyboard: Keyboard? = null
    
    private var currentKeyboard: Keyboard? = null
    private var currentLanguage = LANGUAGE_ENGLISH
    private var isCapsLock = false
    private var isShifted = false
    private var isSymbols = false
    
    private lateinit var settingsManager: SettingsManager
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var emojiManager: EmojiManager
    private lateinit var soundManager: SoundManager
    private lateinit var avroConverter: AvroConverter
    
    private var adView: AdView? = null
    private var lastShiftTime: Long = 0
    private val doubleClickThreshold = 300L
    
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main)
    
    private var pinnedMessages = mutableListOf<String>()
    private var clipboardHistory = mutableListOf<String>()

    override fun onCreate() {
        super.onCreate()
        settingsManager = SettingsManager(this)
        clipboardManager = ClipboardManager(this)
        emojiManager = EmojiManager(this)
        soundManager = SoundManager(this)
        avroConverter = AvroConverter()
        loadPinnedMessages()
    }

    override fun onCreateInputView(): View {
        val inflater = LayoutInflater.from(this)
        val mainView = inflater.inflate(R.layout.keyboard_main, null) as FrameLayout
        
        keyboardView = mainView.findViewById(R.id.keyboard_view)
        candidateView = mainView.findViewById(R.id.candidate_view)
        clipboardBar = mainView.findViewById(R.id.clipboard_bar)
        emojiPanel = mainView.findViewById(R.id.emoji_panel)
        adContainer = mainView.findViewById(R.id.ad_container)
        
        keyboardView.setOnKeyboardActionListener(this)
        keyboardView.setService(this)
        
        setupKeyboards()
        setupClipboardBar()
        setupEmojiPanel()
        setupAds()
        
        return mainView
    }

    private fun setupKeyboards() {
        englishKeyboard = Keyboard(this, R.xml.keyboard_english)
        englishShiftedKeyboard = Keyboard(this, R.xml.keyboard_english_shift)
        banglaKeyboard = Keyboard(this, R.xml.keyboard_bangla)
        banglaShiftedKeyboard = Keyboard(this, R.xml.keyboard_bangla_shift)
        avroKeyboard = Keyboard(this, R.xml.keyboard_english)
        symbolsKeyboard = Keyboard(this, R.xml.keyboard_symbols)
        symbolsShiftedKeyboard = Keyboard(this, R.xml.keyboard_symbols_shift)
        numericKeyboard = Keyboard(this, R.xml.keyboard_numeric)
        
        currentKeyboard = englishKeyboard
        keyboardView.keyboard = currentKeyboard
    }

    private fun setupClipboardBar() {
        clipboardBar.visibility = if (settingsManager.showClipboardBar) View.VISIBLE else View.GONE
        updateClipboardBar()
    }

    private fun setupEmojiPanel() {
        emojiPanel.visibility = View.GONE
    }

    private fun setupAds() {
        if (settingsManager.isPremium) return
        
        adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = "ca-app-pub-3940256099942544/6300978111" // Test ID
        }
        
        adContainer.addView(adView)
        adView?.loadAd(AdRequest.Builder().build())
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        
        when (attribute?.inputType?.and(InputType.TYPE_MASK_CLASS)) {
            InputType.TYPE_CLASS_NUMBER,
            InputType.TYPE_CLASS_DATETIME,
            InputType.TYPE_CLASS_PHONE -> {
                currentKeyboard = numericKeyboard
            }
            else -> {
                if (currentKeyboard == numericKeyboard) {
                    setKeyboardBasedOnLanguage()
                }
            }
        }
        
        keyboardView.keyboard = currentKeyboard
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        soundManager.loadSounds()
        updateClipboardBar()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        soundManager.release()
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val inputConnection = currentInputConnection ?: return
        
        playSoundAndVibrate()
        
        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                handleDelete(inputConnection)
            }
            Keyboard.KEYCODE_SHIFT -> {
                handleShift()
            }
            Keyboard.KEYCODE_DONE -> {
                inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            }
            Keyboard.KEYCODE_MODE_CHANGE -> {
                handleModeChange()
            }
            Keyboard.KEYCODE_ALT -> {
                handleSymbols()
            }
            KEYCODE_LANGUAGE_SWITCH -> {
                switchLanguage()
            }
            KEYCODE_EMOJI -> {
                toggleEmojiPanel()
            }
            KEYCODE_CLIPBOARD -> {
                showClipboardHistory()
            }
            KEYCODE_GIF -> {
                showGifPanel()
            }
            KEYCODE_SETTINGS -> {
                openSettings()
            }
            KEYCODE_PIN -> {
                pinCurrentText(inputConnection)
            }
            KEYCODE_DELETE_WORD -> {
                deleteWord(inputConnection)
            }
            KEYCODE_VOICE -> {
                startVoiceInput()
            }
            else -> {
                handleCharacterInput(primaryCode, inputConnection)
            }
        }
    }

    private fun handleCharacterInput(primaryCode: Int, inputConnection: InputConnection) {
        val char = primaryCode.toChar()
        
        when (currentLanguage) {
            LANGUAGE_AVRO -> {
                // Avro phonetic input handling
                val beforeCursor = inputConnection.getTextBeforeCursor(20, 0)?.toString() ?: ""
                val avroText = avroConverter.convert(beforeCursor + char)
                
                if (avroText != beforeCursor + char) {
                    inputConnection.deleteSurroundingText(beforeCursor.length, 0)
                    inputConnection.commitText(avroText, 1)
                } else {
                    inputConnection.commitText(char.toString(), 1)
                }
            }
            LANGUAGE_BANGLA -> {
                // Direct Bangla Unicode input
                val banglaChar = convertToBangla(char)
                inputConnection.commitText(banglaChar, 1)
            }
            else -> {
                // English input
                if (isShifted || isCapsLock) {
                    inputConnection.commitText(char.uppercaseChar().toString(), 1)
                    if (!isCapsLock) {
                        isShifted = false
                        updateKeyboardShiftState()
                    }
                } else {
                    inputConnection.commitText(char.toString(), 1)
                }
            }
        }
    }

    private fun convertToBangla(char: Char): String {
        return BanglaConverter.englishToBangla(char)
    }

    private fun handleDelete(inputConnection: InputConnection) {
        val selectedText = inputConnection.getSelectedText(0)
        if (TextUtils.isEmpty(selectedText)) {
            inputConnection.deleteSurroundingText(1, 0)
        } else {
            inputConnection.commitText("", 1)
        }
    }

    private fun handleShift() {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastShiftTime < doubleClickThreshold) {
            isCapsLock = !isCapsLock
            isShifted = isCapsLock
            Toast.makeText(this, if (isCapsLock) "Caps Lock On" else "Caps Lock Off", Toast.LENGTH_SHORT).show()
        } else {
            isShifted = !isShifted
            isCapsLock = false
        }
        lastShiftTime = currentTime
        updateKeyboardShiftState()
    }

    private fun updateKeyboardShiftState() {
        currentKeyboard = when {
            isSymbols -> currentKeyboard
            currentLanguage == LANGUAGE_BANGLA -> if (isShifted || isCapsLock) banglaShiftedKeyboard else banglaKeyboard
            currentLanguage == LANGUAGE_AVRO -> if (isShifted || isCapsLock) englishShiftedKeyboard else englishKeyboard
            else -> if (isShifted || isCapsLock) englishShiftedKeyboard else englishKeyboard
        }
        keyboardView.keyboard = currentKeyboard
        keyboardView.isShifted = isShifted || isCapsLock
    }

    private fun handleModeChange() {
        switchLanguage()
    }

    private fun handleSymbols() {
        isSymbols = !isSymbols
        currentKeyboard = if (isSymbols) {
            if (isShifted) symbolsShiftedKeyboard else symbolsKeyboard
        } else {
            setKeyboardBasedOnLanguage()
        }
        keyboardView.keyboard = currentKeyboard
    }

    private fun switchLanguage() {
        currentLanguage = (currentLanguage + 1) % 3
        val languageName = when (currentLanguage) {
            LANGUAGE_ENGLISH -> "English"
            LANGUAGE_BANGLA -> "বাংলা"
            LANGUAGE_AVRO -> "অভ্র"
            else -> "English"
        }
        Toast.makeText(this, languageName, Toast.LENGTH_SHORT).show()
        setKeyboardBasedOnLanguage()
        keyboardView.keyboard = currentKeyboard
    }

    fun switchLanguageBySwipe(direction: Int) {
        if (direction > 0) {
            currentLanguage = (currentLanguage + 1) % 3
        } else {
            currentLanguage = (currentLanguage + 2) % 3
        }
        val languageName = when (currentLanguage) {
            LANGUAGE_ENGLISH -> "English"
            LANGUAGE_BANGLA -> "বাংলা"
            LANGUAGE_AVRO -> "অভ্র"
            else -> "English"
        }
        Toast.makeText(this, languageName, Toast.LENGTH_SHORT).show()
        setKeyboardBasedOnLanguage()
        keyboardView.keyboard = currentKeyboard
    }

    private fun setKeyboardBasedOnLanguage(): Keyboard? {
        currentKeyboard = when (currentLanguage) {
            LANGUAGE_BANGLA -> if (isShifted) banglaShiftedKeyboard else banglaKeyboard
            LANGUAGE_AVRO -> if (isShifted) englishShiftedKeyboard else englishKeyboard
            else -> if (isShifted) englishShiftedKeyboard else englishKeyboard
        }
        return currentKeyboard
    }

    private fun toggleEmojiPanel() {
        if (emojiPanel.visibility == View.VISIBLE) {
            emojiPanel.visibility = View.GONE
            keyboardView.visibility = View.VISIBLE
        } else {
            emojiPanel.visibility = View.VISIBLE
            keyboardView.visibility = View.GONE
            showEmojiGrid()
        }
    }

    private fun showEmojiGrid() {
        emojiPanel.removeAllViews()
        val emojiView = emojiManager.getEmojiView(this) { emoji ->
            currentInputConnection?.commitText(emoji, 1)
        }
        emojiPanel.addView(emojiView)
    }

    private fun showGifPanel() {
        // Show GIF selection panel
        val intent = Intent(this, GifActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    private fun showClipboardHistory() {
        clipboardHistory = clipboardManager.getClipboardHistory().toMutableList()
        // Show clipboard history popup
        showClipboardPopup()
    }

    private fun showClipboardPopup() {
        val popupView = LayoutInflater.from(this).inflate(R.layout.popup_clipboard, null)
        val popup = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        
        val container = popupView.findViewById<LinearLayout>(R.id.clipboard_container)
        clipboardHistory.forEach { item ->
            val textView = TextView(this).apply {
                text = item
                setPadding(20, 20, 20, 20)
                setOnClickListener {
                    currentInputConnection?.commitText(item, 1)
                    popup.dismiss()
                }
            }
            container.addView(textView)
        }
        
        popup.showAtLocation(keyboardView, android.view.Gravity.BOTTOM, 0, 0)
    }

    private fun openSettings() {
        val intent = Intent(this, com.bangla.keyboard.settings.SettingsActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    private fun pinCurrentText(inputConnection: InputConnection) {
        val text = inputConnection.getTextBeforeCursor(100, 0)?.toString() ?: ""
        if (text.isNotEmpty()) {
            pinnedMessages.add(0, text)
            if (pinnedMessages.size > 10) pinnedMessages.removeAt(10)
            savePinnedMessages()
            updateClipboardBar()
            Toast.makeText(this, "Text pinned!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteWord(inputConnection: InputConnection) {
        val beforeCursor = inputConnection.getTextBeforeCursor(50, 0)?.toString() ?: ""
        val words = beforeCursor.split("\\s+".toRegex())
        if (words.isNotEmpty()) {
            val lastWord = words.last()
            inputConnection.deleteSurroundingText(lastWord.length, 0)
        }
    }

    private fun startVoiceInput() {
        // Trigger voice input
        val intent = Intent("android.speech.action.RECOGNIZE_SPEECH")
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateClipboardBar() {
        clipboardBar.removeAllViews()
        
        // Add pin button
        val pinBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_pin)
            setOnClickListener { pinCurrentText(currentInputConnection) }
        }
        clipboardBar.addView(pinBtn)
        
        // Add pinned messages
        pinnedMessages.take(5).forEach { message ->
            val textView = TextView(this).apply {
                text = if (message.length > 20) message.substring(0, 20) + "..." else message
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(10, 5, 10, 5)
                setBackgroundResource(R.drawable.bg_pinned_item)
                setOnClickListener {
                    currentInputConnection?.commitText(message, 1)
                }
            }
            clipboardBar.addView(textView)
        }
    }

    private fun playSoundAndVibrate() {
        if (settingsManager.soundEnabled) {
            soundManager.playKeySound()
        }
        if (settingsManager.vibrationEnabled) {
            vibrate()
        }
    }

    private fun vibrate() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(30)
        }
    }

    private fun loadPinnedMessages() {
        val prefs = getSharedPreferences("keyboard_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getStringSet("pinned_messages", setOf()) ?: setOf()
        pinnedMessages = saved.toMutableList()
    }

    private fun savePinnedMessages() {
        val prefs = getSharedPreferences("keyboard_prefs", Context.MODE_PRIVATE)
        prefs.edit().putStringSet("pinned_messages", pinnedMessages.toSet()).apply()
    }

    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {
        currentInputConnection?.commitText(text, 1)
    }
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
