package com.bangla.keyboard.ime

import android.content.Context
import android.graphics.*
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.util.AttributeSet
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import kotlin.math.abs

class CustomKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.keyboardViewStyle
) : KeyboardView(context, attrs, defStyleAttr) {

    companion object {
        const val TAG = "CustomKeyboardView"
        const val SWIPE_THRESHOLD = 100
        const val SWIPE_VELOCITY_THRESHOLD = 100
    }
    
    private var service: BanglaKeyboardService? = null
    private var gestureDetector: GestureDetector
    private var spacebarDownX: Float = 0f
    private var isSpacebarSwipe = false
    private var lastTouchX: Float = 0f
    private var languageIndicatorPaint: Paint = Paint().apply {
        color = Color.WHITE
        textSize = 30f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    
    private var keyBackgroundPaint: Paint = Paint().apply {
        isAntiAlias = true
    }
    
    private var specialKeys = mapOf(
        BanglaKeyboardService.KEYCODE_LANGUAGE_SWITCH to "🌐",
        BanglaKeyboardService.KEYCODE_EMOJI to "😊",
        BanglaKeyboardService.KEYCODE_CLIPBOARD to "📋",
        BanglaKeyboardService.KEYCODE_GIF to "GIF",
        BanglaKeyboardService.KEYCODE_SETTINGS to "⚙",
        BanglaKeyboardService.KEYCODE_PIN to "📌",
        BanglaKeyboardService.KEYCODE_DELETE_WORD to "⌫⌫",
        BanglaKeyboardService.KEYCODE_VOICE to "🎤"
    )

    init {
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                
                val diffX = e2.x - e1.x
                val diffY = e2.y - e1.y
                
                if (abs(diffX) > abs(diffY)) {
                    if (abs(diffX) > SWIPE_THRESHOLD && abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight()
                        } else {
                            onSwipeLeft()
                        }
                        return true
                    }
                }
                return false
            }
            
            override fun onLongPress(e: MotionEvent) {
                super.onLongPress(e)
                // Handle long press for alternate characters
            }
        })
    }

    fun setService(service: BanglaKeyboardService) {
        this.service = service
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        
        val x = event.x
        val y = event.y
        
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = x
                val key = getKeyAt(x, y)
                if (key?.codes?.get(0) == 32) { // Spacebar
                    spacebarDownX = x
                    isSpacebarSwipe = true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (isSpacebarSwipe) {
                    val diffX = x - spacebarDownX
                    if (abs(diffX) > SWIPE_THRESHOLD) {
                        if (diffX > 0) {
                            service?.switchLanguageBySwipe(1)
                        } else {
                            service?.switchLanguageBySwipe(-1)
                        }
                        isSpacebarSwipe = false
                        return true
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isSpacebarSwipe = false
            }
        }
        
        return super.onTouchEvent(event)
    }

    private fun getKeyAt(x: Float, y: Float): Keyboard.Key? {
        val keys = keyboard?.keys
        keys?.forEach { key ->
            if (key.isInside(x.toInt(), y.toInt())) {
                return key
            }
        }
        return null
    }

    private fun onSwipeLeft() {
        // Handle global swipe left
    }

    private fun onSwipeRight() {
        // Handle global swipe right
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        // Draw custom key labels
        keyboard?.keys?.forEach { key ->
            val specialLabel = specialKeys[key.codes?.get(0) ?: 0]
            if (specialLabel != null) {
                drawSpecialKey(canvas, key, specialLabel)
            }
            
            // Draw language indicator on spacebar
            if (key.codes?.get(0) == 32) {
                drawLanguageIndicator(canvas, key)
            }
        }
    }

    private fun drawSpecialKey(canvas: Canvas, key: Keyboard.Key, label: String) {
        val bounds = Rect(key.x, key.y, key.x + key.width, key.y + key.height)
        
        // Draw background
        keyBackgroundPaint.color = Color.parseColor("#4A5568")
        canvas.drawRoundRect(
            bounds.left + 5f,
            bounds.top + 5f,
            bounds.right - 5f,
            bounds.bottom - 5f,
            10f,
            10f,
            keyBackgroundPaint
        )
        
        // Draw label
        canvas.drawText(
            label,
            (bounds.left + bounds.right) / 2f,
            (bounds.top + bounds.bottom) / 2f + 10f,
            languageIndicatorPaint
        )
    }

    private fun drawLanguageIndicator(canvas: Canvas, key: Keyboard.Key) {
        val languageText = when (service?.let { 
            BanglaKeyboardService::class.java.declaredFields
                .find { it.name == "currentLanguage" }
                ?.apply { isAccessible = true }
                ?.get(it) as? Int 
        }) {
            BanglaKeyboardService.LANGUAGE_ENGLISH -> "EN"
            BanglaKeyboardService.LANGUAGE_BANGLA -> "বাং"
            BanglaKeyboardService.LANGUAGE_AVRO -> "অ"
            else -> "EN"
        }
        
        val bounds = Rect(key.x, key.y, key.x + key.width, key.y + key.height)
        
        // Draw small indicator at bottom of spacebar
        val indicatorPaint = Paint().apply {
            color = Color.parseColor("#63B3ED")
            textSize = 24f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        
        canvas.drawText(
            languageText,
            (bounds.left + bounds.right) / 2f,
            bounds.bottom - 10f,
            indicatorPaint
        )
        
        // Draw swipe hint
        val hintPaint = Paint().apply {
            color = Color.parseColor("#A0AEC0")
            textSize = 18f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        
        canvas.drawText(
            "◀ swipe ▶",
            (bounds.left + bounds.right) / 2f,
            bounds.top + 20f,
            hintPaint
        )
    }

    fun setLanguageIndicator(languageCode: Int) {
        invalidate()
    }
}
