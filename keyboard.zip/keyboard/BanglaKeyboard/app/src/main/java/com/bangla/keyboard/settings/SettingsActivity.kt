package com.bangla.keyboard.settings

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.bangla.keyboard.R
import com.bangla.keyboard.store.PremiumStoreActivity

class SettingsActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = getString(R.string.settings)
        }
        
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    class SettingsFragment : PreferenceFragmentCompat() {
        
        private lateinit var settingsManager: SettingsManager
        
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            settingsManager = SettingsManager(requireContext())
            
            setupPreferences()
        }
        
        private fun setupPreferences() {
            // Sound preference
            findPreference<SwitchPreferenceCompat>("sound_enabled")?.apply {
                isChecked = settingsManager.soundEnabled
                setOnPreferenceChangeListener { _, newValue ->
                    settingsManager.soundEnabled = newValue as Boolean
                    true
                }
            }
            
            // Vibration preference
            findPreference<SwitchPreferenceCompat>("vibration_enabled")?.apply {
                isChecked = settingsManager.vibrationEnabled
                setOnPreferenceChangeListener { _, newValue ->
                    settingsManager.vibrationEnabled = newValue as Boolean
                    true
                }
            }
            
            // Clipboard bar preference
            findPreference<SwitchPreferenceCompat>("show_clipboard_bar")?.apply {
                isChecked = settingsManager.showClipboardBar
                setOnPreferenceChangeListener { _, newValue ->
                    settingsManager.showClipboardBar = newValue as Boolean
                    true
                }
            }
            
            // Predictions preference
            findPreference<SwitchPreferenceCompat>("show_predictions")?.apply {
                isChecked = settingsManager.showPredictions
                setOnPreferenceChangeListener { _, newValue ->
                    settingsManager.showPredictions = newValue as Boolean
                    true
                }
            }
            
            // Auto-correct preference
            findPreference<SwitchPreferenceCompat>("auto_correct")?.apply {
                isChecked = settingsManager.autoCorrect
                setOnPreferenceChangeListener { _, newValue ->
                    settingsManager.autoCorrect = newValue as Boolean
                    true
                }
            }
            
            // Theme preference
            findPreference<Preference>("keyboard_theme")?.apply {
                summary = settingsManager.theme
                setOnPreferenceClickListener {
                    showThemeSelector()
                    true
                }
            }
            
            // Premium store
            findPreference<Preference>("premium_store")?.apply {
                setOnPreferenceClickListener {
                    startActivity(Intent(requireContext(), PremiumStoreActivity::class.java))
                    true
                }
            }
            
            // Reset settings
            findPreference<Preference>("reset_settings")?.apply {
                setOnPreferenceClickListener {
                    settingsManager.resetToDefaults()
                    Toast.makeText(requireContext(), "Settings reset to default", Toast.LENGTH_SHORT).show()
                    activity?.recreate()
                    true
                }
            }
            
            // About
            findPreference<Preference>("about")?.apply {
                summary = "Version ${getAppVersion()}"
            }
        }
        
        private fun showThemeSelector() {
            val themes = arrayOf("Auto", "Light", "Dark", "Blue", "Green", "Purple", "Pink")
            val values = arrayOf(
                SettingsManager.THEME_AUTO,
                SettingsManager.THEME_LIGHT,
                SettingsManager.THEME_DARK,
                SettingsManager.THEME_BLUE,
                SettingsManager.THEME_GREEN,
                SettingsManager.THEME_PURPLE,
                SettingsManager.THEME_PINK
            )
            
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Select Theme")
                .setItems(themes) { _, which ->
                    settingsManager.theme = values[which]
                    findPreference<Preference>("keyboard_theme")?.summary = values[which]
                }
                .show()
        }
        
        private fun getAppVersion(): String {
            return try {
                requireContext().packageManager.getPackageInfo(
                    requireContext().packageName, 0
                ).versionName ?: "1.0.0"
            } catch (e: Exception) {
                "1.0.0"
            }
        }
    }
}
