package com.bangla.keyboard.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class SettingsManager(context: Context) {
    
    companion object {
        const val PREFS_NAME = "bangla_keyboard_settings"
        const val KEY_SOUND_ENABLED = "sound_enabled"
        const val KEY_VIBRATION_ENABLED = "vibration_enabled"
        const val KEY_CLIPBOARD_BAR = "show_clipboard_bar"
        const val KEY_PREDICTIONS = "show_predictions"
        const val KEY_AUTO_CORRECT = "auto_correct"
        const val KEY_THEME = "keyboard_theme"
        const val KEY_FONT_SIZE = "font_size"
        const val KEY_KEY_HEIGHT = "key_height"
        const val KEY_IS_PREMIUM = "is_premium"
        const val KEY_ADS_REMOVED = "ads_removed"
        const val KEY_DOUBLE_SPACE_PERIOD = "double_space_period"
        const val KEY_AUTO_CAPITALIZE = "auto_capitalize"
        const val KEY_SHOW_NUMBER_ROW = "show_number_row"
        const val KEY_LONG_PRESS_DELAY = "long_press_delay"
        const val KEY_POPUP_PREVIEW = "popup_preview"
        const val KEY_GESTURE_TYPING = "gesture_typing"
        const val KEY_VOICE_INPUT = "voice_input"
        const val KEY_EMOJI_PREDICTIONS = "emoji_predictions"
        const val KEY_PERSONALIZED_SUGGESTIONS = "personalized_suggestions"
        const val KEY_SYNC_ENABLED = "sync_enabled"
        const val KEY_NIGHT_MODE = "night_mode"
        const val KEY_SOUND_VOLUME = "sound_volume"
        const val KEY_VIBRATION_STRENGTH = "vibration_strength"
        const val KEY_KEYBOARD_HEIGHT_PERCENT = "keyboard_height_percent"
        const val KEY_BOTTOM_PADDING = "bottom_padding"
        
        // Theme constants
        const val THEME_LIGHT = "light"
        const val THEME_DARK = "dark"
        const val THEME_AUTO = "auto"
        const val THEME_BLUE = "blue"
        const val THEME_GREEN = "green"
        const val THEME_PURPLE = "purple"
        const val THEME_PINK = "pink"
        const val THEME_CUSTOM = "custom"
    }
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    
    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit { putBoolean(KEY_SOUND_ENABLED, value) }
    
    var vibrationEnabled: Boolean
        get() = prefs.getBoolean(KEY_VIBRATION_ENABLED, true)
        set(value) = prefs.edit { putBoolean(KEY_VIBRATION_ENABLED, value) }
    
    var showClipboardBar: Boolean
        get() = prefs.getBoolean(KEY_CLIPBOARD_BAR, true)
        set(value) = prefs.edit { putBoolean(KEY_CLIPBOARD_BAR, value) }
    
    var showPredictions: Boolean
        get() = prefs.getBoolean(KEY_PREDICTIONS, true)
        set(value) = prefs.edit { putBoolean(KEY_PREDICTIONS, value) }
    
    var autoCorrect: Boolean
        get() = prefs.getBoolean(KEY_AUTO_CORRECT, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_CORRECT, value) }
    
    var theme: String
        get() = prefs.getString(KEY_THEME, THEME_AUTO) ?: THEME_AUTO
        set(value) = prefs.edit { putString(KEY_THEME, value) }
    
    var fontSize: Int
        get() = prefs.getInt(KEY_FONT_SIZE, 18)
        set(value) = prefs.edit { putInt(KEY_FONT_SIZE, value) }
    
    var keyHeight: Int
        get() = prefs.getInt(KEY_KEY_HEIGHT, 48)
        set(value) = prefs.edit { putInt(KEY_KEY_HEIGHT, value) }
    
    var isPremium: Boolean
        get() = prefs.getBoolean(KEY_IS_PREMIUM, false)
        set(value) = prefs.edit { putBoolean(KEY_IS_PREMIUM, value) }
    
    var adsRemoved: Boolean
        get() = prefs.getBoolean(KEY_ADS_REMOVED, false)
        set(value) = prefs.edit { putBoolean(KEY_ADS_REMOVED, value) }
    
    var doubleSpacePeriod: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_SPACE_PERIOD, true)
        set(value) = prefs.edit { putBoolean(KEY_DOUBLE_SPACE_PERIOD, value) }
    
    var autoCapitalize: Boolean
        get() = prefs.getBoolean(KEY_AUTO_CAPITALIZE, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_CAPITALIZE, value) }
    
    var showNumberRow: Boolean
        get() = prefs.getBoolean(KEY_SHOW_NUMBER_ROW, false)
        set(value) = prefs.edit { putBoolean(KEY_SHOW_NUMBER_ROW, value) }
    
    var longPressDelay: Int
        get() = prefs.getInt(KEY_LONG_PRESS_DELAY, 400)
        set(value) = prefs.edit { putInt(KEY_LONG_PRESS_DELAY, value) }
    
    var popupPreview: Boolean
        get() = prefs.getBoolean(KEY_POPUP_PREVIEW, true)
        set(value) = prefs.edit { putBoolean(KEY_POPUP_PREVIEW, value) }
    
    var gestureTyping: Boolean
        get() = prefs.getBoolean(KEY_GESTURE_TYPING, false)
        set(value) = prefs.edit { putBoolean(KEY_GESTURE_TYPING, value) }
    
    var voiceInput: Boolean
        get() = prefs.getBoolean(KEY_VOICE_INPUT, true)
        set(value) = prefs.edit { putBoolean(KEY_VOICE_INPUT, value) }
    
    var emojiPredictions: Boolean
        get() = prefs.getBoolean(KEY_EMOJI_PREDICTIONS, true)
        set(value) = prefs.edit { putBoolean(KEY_EMOJI_PREDICTIONS, value) }
    
    var personalizedSuggestions: Boolean
        get() = prefs.getBoolean(KEY_PERSONALIZED_SUGGESTIONS, true)
        set(value) = prefs.edit { putBoolean(KEY_PERSONALIZED_SUGGESTIONS, value) }
    
    var syncEnabled: Boolean
        get() = prefs.getBoolean(KEY_SYNC_ENABLED, false)
        set(value) = prefs.edit { putBoolean(KEY_SYNC_ENABLED, value) }
    
    var nightMode: Boolean
        get() = prefs.getBoolean(KEY_NIGHT_MODE, false)
        set(value) = prefs.edit { putBoolean(KEY_NIGHT_MODE, value) }
    
    var soundVolume: Int
        get() = prefs.getInt(KEY_SOUND_VOLUME, 50)
        set(value) = prefs.edit { putInt(KEY_SOUND_VOLUME, value) }
    
    var vibrationStrength: Int
        get() = prefs.getInt(KEY_VIBRATION_STRENGTH, 50)
        set(value) = prefs.edit { putInt(KEY_VIBRATION_STRENGTH, value) }
    
    var keyboardHeightPercent: Int
        get() = prefs.getInt(KEY_KEYBOARD_HEIGHT_PERCENT, 100)
        set(value) = prefs.edit { putInt(KEY_KEYBOARD_HEIGHT_PERCENT, value) }
    
    var bottomPadding: Int
        get() = prefs.getInt(KEY_BOTTOM_PADDING, 0)
        set(value) = prefs.edit { putInt(KEY_BOTTOM_PADDING, value) }
    
    fun resetToDefaults() {
        prefs.edit {
            clear()
            putBoolean(KEY_SOUND_ENABLED, true)
            putBoolean(KEY_VIBRATION_ENABLED, true)
            putBoolean(KEY_CLIPBOARD_BAR, true)
            putBoolean(KEY_PREDICTIONS, true)
            putBoolean(KEY_AUTO_CORRECT, true)
            putString(KEY_THEME, THEME_AUTO)
            putInt(KEY_FONT_SIZE, 18)
            putInt(KEY_KEY_HEIGHT, 48)
            putBoolean(KEY_DOUBLE_SPACE_PERIOD, true)
            putBoolean(KEY_AUTO_CAPITALIZE, true)
            putBoolean(KEY_POPUP_PREVIEW, true)
            putBoolean(KEY_VOICE_INPUT, true)
            putBoolean(KEY_EMOJI_PREDICTIONS, true)
            putInt(KEY_SOUND_VOLUME, 50)
            putInt(KEY_VIBRATION_STRENGTH, 50)
        }
    }
    
    fun getAllSettings(): Map<String, Any?> {
        return mapOf(
            "soundEnabled" to soundEnabled,
            "vibrationEnabled" to vibrationEnabled,
            "showClipboardBar" to showClipboardBar,
            "showPredictions" to showPredictions,
            "autoCorrect" to autoCorrect,
            "theme" to theme,
            "fontSize" to fontSize,
            "keyHeight" to keyHeight,
            "isPremium" to isPremium,
            "doubleSpacePeriod" to doubleSpacePeriod,
            "autoCapitalize" to autoCapitalize,
            "showNumberRow" to showNumberRow,
            "popupPreview" to popupPreview,
            "gestureTyping" to gestureTyping,
            "voiceInput" to voiceInput,
            "emojiPredictions" to emojiPredictions,
            "soundVolume" to soundVolume,
            "vibrationStrength" to vibrationStrength
        )
    }
}
