package com.bangla.keyboard.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.bangla.keyboard.R

class SoundManager(private val context: Context) {
    
    companion object {
        const val SOUND_STANDARD = "standard"
        const val SOUND_MECHANICAL = "mechanical"
        const val SOUND_TYPEWRITER = "typewriter"
        const val SOUND_WATERDROP = "waterdrop"
        const val SOUND_WOOD = "wood"
        const val SOUND_CHEERY = "cheery"
        const val SOUND_DING = "ding"
        const val SOUND_POP = "pop"
        const val SOUND_CLICK = "click"
        const val SOUND_SOFT = "soft"
    }
    
    private var soundPool: SoundPool? = null
    private val soundMap = mutableMapOf<Int, Int>()
    private val settingsManager = com.bangla.keyboard.settings.SettingsManager(context)
    
    private var currentSoundSet = SOUND_STANDARD
    
    // Sound resource mappings
    private val soundSets = mapOf(
        SOUND_STANDARD to listOf(R.raw.key_standard),
        SOUND_MECHANICAL to listOf(R.raw.key_mechanical),
        SOUND_TYPEWRITER to listOf(R.raw.key_typewriter),
        SOUND_WATERDROP to listOf(R.raw.key_waterdrop),
        SOUND_WOOD to listOf(R.raw.key_wood),
        SOUND_CHEERY to listOf(R.raw.key_cheery),
        SOUND_DING to listOf(R.raw.key_ding),
        SOUND_POP to listOf(R.raw.key_pop),
        SOUND_CLICK to listOf(R.raw.key_click),
        SOUND_SOFT to listOf(R.raw.key_soft)
    )
    
    fun loadSounds() {
        release()
        
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(audioAttributes)
            .build()
        
        // Load current sound set
        val sounds = soundSets[currentSoundSet] ?: soundSets[SOUND_STANDARD]!!
        sounds.forEachIndexed { index, resId ->
            soundPool?.load(context, resId, 1)?.let { soundId ->
                soundMap[index] = soundId
            }
        }
    }
    
    fun playKeySound() {
        if (!settingsManager.soundEnabled) return
        
        val volume = settingsManager.soundVolume / 100f
        soundPool?.let { pool ->
            val soundId = soundMap.values.randomOrNull() ?: return
            pool.play(soundId, volume, volume, 1, 0, 1f)
        }
    }
    
    fun playSpecialSound(soundType: Int) {
        if (!settingsManager.soundEnabled) return
        
        val volume = settingsManager.soundVolume / 100f
        soundPool?.let { pool ->
            soundMap[soundType]?.let { soundId ->
                pool.play(soundId, volume, volume, 1, 0, 1f)
            }
        }
    }
    
    fun playBackspaceSound() {
        playKeySound()
    }
    
    fun playEnterSound() {
        playKeySound()
    }
    
    fun playSpaceSound() {
        playKeySound()
    }
    
    fun setSoundSet(soundSet: String) {
        if (soundSets.containsKey(soundSet)) {
            currentSoundSet = soundSet
            loadSounds()
        }
    }
    
    fun getAvailableSoundSets(): List<String> {
        return soundSets.keys.toList()
    }
    
    fun release() {
        soundPool?.release()
        soundPool = null
        soundMap.clear()
    }
}
