package com.bangla.keyboard.store

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.billingclient.api.*
import com.bangla.keyboard.R
import com.bangla.keyboard.settings.SettingsManager
import kotlinx.coroutines.*

class PremiumStoreActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PremiumFeatureAdapter
    private lateinit var billingClient: BillingClient
    private lateinit var settingsManager: SettingsManager
    
    private val features = listOf(
        PremiumFeature(
            "remove_ads",
            "Remove Ads",
            "Remove all advertisements forever",
            R.drawable.ic_no_ads,
            99,
            "₹99"
        ),
        PremiumFeature(
            "premium_themes",
            "Premium Themes",
            "Unlock 50+ exclusive themes",
            R.drawable.ic_theme,
            49,
            "₹49"
        ),
        PremiumFeature(
            "custom_fonts",
            "Custom Fonts",
            "20+ beautiful keyboard fonts",
            R.drawable.ic_font,
            29,
            "₹29"
        ),
        PremiumFeature(
            "gesture_typing",
            "Gesture Typing",
            "Swipe to type faster",
            R.drawable.ic_gesture,
            39,
            "₹39"
        ),
        PremiumFeature(
            "cloud_sync",
            "Cloud Sync",
            "Sync across all devices",
            R.drawable.ic_cloud,
            59,
            "₹59"
        ),
        PremiumFeature(
            "advanced_clipboard",
            "Advanced Clipboard",
            "Unlimited clipboard history",
            R.drawable.ic_clipboard,
            19,
            "₹19"
        ),
        PremiumFeature(
            "custom_sounds",
            "Custom Sounds",
            "Premium typing sounds pack",
            R.drawable.ic_sound,
            15,
            "₹15"
        ),
        PremiumFeature(
            "animated_themes",
            "Animated Themes",
            "Live animated keyboard themes",
            R.drawable.ic_animation,
            79,
            "₹79"
        ),
        PremiumFeature(
            "emoji_pack_1",
            "Exclusive Emojis Pack 1",
            "500+ unique emojis",
            R.drawable.ic_emoji,
            25,
            "₹25"
        ),
        PremiumFeature(
            "emoji_pack_2",
            "Exclusive Emojis Pack 2",
            "500+ more unique emojis",
            R.drawable.ic_emoji2,
            25,
            "₹25"
        ),
        PremiumFeature(
            "gif_pack",
            "Premium GIF Pack",
            "1000+ exclusive GIFs",
            R.drawable.ic_gif,
            35,
            "₹35"
        ),
        PremiumFeature(
            "sticker_pack",
            "Sticker Pack",
            "500+ custom stickers",
            R.drawable.ic_sticker,
            29,
            "₹29"
        ),
        PremiumFeature(
            "translator",
            "Built-in Translator",
            "Translate while typing",
            R.drawable.ic_translate,
            49,
            "₹49"
        ),
        PremiumFeature(
            "grammar_check",
            "Grammar Check",
            "Advanced grammar correction",
            R.drawable.ic_grammar,
            39,
            "₹39"
        ),
        PremiumFeature(
            "voice_typing",
            "Advanced Voice",
            "Enhanced voice recognition",
            R.drawable.ic_voice,
            45,
            "₹45"
        ),
        PremiumFeature(
            "smart_reply",
            "Smart Reply",
            "AI-powered quick replies",
            R.drawable.ic_smart_reply,
            59,
            "₹59"
        ),
        PremiumFeature(
            "text_shortcuts",
            "Text Shortcuts",
            "Create custom shortcuts",
            R.drawable.ic_shortcut,
            19,
            "₹19"
        ),
        PremiumFeature(
            "backup_restore",
            "Backup & Restore",
            "Full data backup",
            R.drawable.ic_backup,
            25,
            "₹25"
        ),
        PremiumFeature(
            "privacy_mode",
            "Privacy Mode",
            "Incognito keyboard mode",
            R.drawable.ic_privacy,
            35,
            "₹35"
        ),
        PremiumFeature(
            "stats",
            "Typing Statistics",
            "Detailed typing analytics",
            R.drawable.ic_stats,
            15,
            "₹15"
        ),
        PremiumFeature(
            "all_premium",
            "ALL PREMIUM",
            "Unlock everything!",
            R.drawable.ic_premium_all,
            299,
            "₹299",
            true
        )
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_premium_store)
        
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = getString(R.string.premium_store)
        }
        
        settingsManager = SettingsManager(this)
        setupRecyclerView()
        setupBilling()
    }
    
    private fun setupRecyclerView() {
        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = GridLayoutManager(this, 2)
        adapter = PremiumFeatureAdapter(features) { feature ->
            purchaseFeature(feature)
        }
        recyclerView.adapter = adapter
    }
    
    private fun setupBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener(purchasesUpdatedListener)
            .enablePendingPurchases()
            .build()
        
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryAvailableProducts()
                }
            }
            
            override fun onBillingServiceDisconnected() {
                // Retry connection
            }
        })
    }
    
    private val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        }
    }
    
    private fun queryAvailableProducts() {
        val skuList = features.map { it.id }
        val params = SkuDetailsParams.newBuilder()
            .setSkusList(skuList)
            .setType(BillingClient.SkuType.INAPP)
            .build()
        
        billingClient.querySkuDetailsAsync(params) { billingResult, skuDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                skuDetailsList?.let {
                    adapter.updateSkuDetails(it)
                }
            }
        }
    }
    
    private fun purchaseFeature(feature: PremiumFeature) {
        val skuDetails = adapter.getSkuDetails(feature.id) ?: return
        
        val billingFlowParams = BillingFlowParams.newBuilder()
            .setSkuDetails(skuDetails)
            .build()
        
        billingClient.launchBillingFlow(this, billingFlowParams)
    }
    
    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            // Grant the premium feature
            grantPremiumFeature(purchase.skus.firstOrNull())
            
            // Acknowledge purchase
            if (!purchase.isAcknowledged) {
                val acknowledgeParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient.acknowledgePurchase(acknowledgeParams) {}
            }
        }
    }
    
    private fun grantPremiumFeature(sku: String?) {
        when (sku) {
            "remove_ads" -> {
                settingsManager.adsRemoved = true
                Toast.makeText(this, "Ads removed!", Toast.LENGTH_SHORT).show()
            }
            "premium_themes" -> {
                Toast.makeText(this, "Premium themes unlocked!", Toast.LENGTH_SHORT).show()
            }
            "all_premium" -> {
                settingsManager.isPremium = true
                settingsManager.adsRemoved = true
                Toast.makeText(this, "All premium features unlocked!", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(this, "Feature unlocked!", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        billingClient.endConnection()
    }
    
    data class PremiumFeature(
        val id: String,
        val name: String,
        val description: String,
        val iconRes: Int,
        val price: Int,
        val priceString: String,
        val isFeatured: Boolean = false
    )
    
    class PremiumFeatureAdapter(
        private val features: List<PremiumFeature>,
        private val onPurchaseClick: (PremiumFeature) -> Unit
    ) : RecyclerView.Adapter<PremiumFeatureAdapter.ViewHolder>() {
        
        private val skuDetailsMap = mutableMapOf<String, SkuDetails>()
        
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(R.id.feature_icon)
            val name: TextView = view.findViewById(R.id.feature_name)
            val description: TextView = view.findViewById(R.id.feature_description)
            val price: TextView = view.findViewById(R.id.feature_price)
            val button: Button = view.findViewById(R.id.purchase_button)
            val card: View = view.findViewById(R.id.feature_card)
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_premium_feature, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val feature = features[position]
            
            holder.icon.setImageResource(feature.iconRes)
            holder.name.text = feature.name
            holder.description.text = feature.description
            holder.price.text = feature.priceString
            
            if (feature.isFeatured) {
                holder.card.setBackgroundResource(R.drawable.bg_featured_card)
                holder.button.text = "BUY ALL"
            } else {
                holder.card.setBackgroundResource(R.drawable.bg_premium_card)
                holder.button.text = "BUY"
            }
            
            holder.button.setOnClickListener {
                onPurchaseClick(feature)
            }
        }
        
        override fun getItemCount() = features.size
        
        fun updateSkuDetails(skuDetailsList: List<SkuDetails>) {
            skuDetailsList.forEach { skuDetailsMap[it.sku] = it }
            notifyDataSetChanged()
        }
        
        fun getSkuDetails(sku: String): SkuDetails? {
            return skuDetailsMap[sku]
        }
    }
}
