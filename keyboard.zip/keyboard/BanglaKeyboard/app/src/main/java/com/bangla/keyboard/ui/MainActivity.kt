package com.bangla.keyboard.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bangla.keyboard.R
import com.bangla.keyboard.settings.SettingsActivity
import com.bangla.keyboard.store.PremiumStoreActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class MainActivity : AppCompatActivity() {
    
    private lateinit var btnEnableKeyboard: Button
    private lateinit var btnSelectKeyboard: Button
    private lateinit var btnSettings: Button
    private lateinit var btnPremium: Button
    private lateinit var tvStatus: TextView
    private lateinit var adView: AdView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize Mobile Ads
        MobileAds.initialize(this) {}
        
        initViews()
        setupListeners()
        checkKeyboardStatus()
        loadAds()
    }
    
    private fun initViews() {
        btnEnableKeyboard = findViewById(R.id.btn_enable_keyboard)
        btnSelectKeyboard = findViewById(R.id.btn_select_keyboard)
        btnSettings = findViewById(R.id.btn_settings)
        btnPremium = findViewById(R.id.btn_premium)
        tvStatus = findViewById(R.id.tv_status)
        adView = findViewById(R.id.adView)
    }
    
    private fun setupListeners() {
        btnEnableKeyboard.setOnClickListener {
            openKeyboardSettings()
        }
        
        btnSelectKeyboard.setOnClickListener {
            showInputMethodPicker()
        }
        
        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        
        btnPremium.setOnClickListener {
            startActivity(Intent(this, PremiumStoreActivity::class.java))
        }
    }
    
    private fun loadAds() {
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
    }
    
    private fun openKeyboardSettings() {
        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Enable 'Bangla Keyboard' from the list", Toast.LENGTH_LONG).show()
    }
    
    private fun showInputMethodPicker() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }
    
    private fun checkKeyboardStatus() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val enabledInputMethods = imm.enabledInputMethodList
        
        val isKeyboardEnabled = enabledInputMethods.any { 
            it.packageName == packageName 
        }
        
        if (isKeyboardEnabled) {
            tvStatus.text = "✅ Keyboard is enabled!"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
            btnEnableKeyboard.text = "Keyboard Enabled"
            btnEnableKeyboard.isEnabled = false
        } else {
            tvStatus.text = "❌ Keyboard is not enabled"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
            btnEnableKeyboard.text = "Enable Keyboard"
            btnEnableKeyboard.isEnabled = true
        }
    }
    
    override fun onResume() {
        super.onResume()
        checkKeyboardStatus()
    }
}
