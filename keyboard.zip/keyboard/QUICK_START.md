# 🚀 Quick Start - 5 Minutes Setup

## Option 1: Use Android Studio (Recommended for Beginners)

### Step 1: Download & Install
1. Download Android Studio: https://developer.android.com/studio
2. Install it (Just click Next → Next → Finish)

### Step 2: Open Project
1. Extract the `BanglaKeyboard.zip` file
2. Open Android Studio
3. Click "Open an existing project"
4. Select the `BanglaKeyboard` folder
5. Wait for Gradle sync (5-10 minutes first time)

### Step 3: Build APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

### Step 4: Find Your APK
Location: `BanglaKeyboard/app/build/outputs/apk/debug/app-debug.apk`

### Step 5: Transfer to Phone
- USB cable, Bluetooth, WhatsApp, or Email

### Step 6: Install
1. Enable "Unknown Sources" in Settings
2. Tap the APK file
3. Click Install

---

## Option 2: Command Line (For Developers)

### Requirements
- Java JDK 17+
- Android SDK
- Environment variables set

### Build Commands
```bash
cd BanglaKeyboard

# Windows
gradlew.bat assembleDebug

# Mac/Linux
./gradlew assembleDebug
```

---

## Option 3: Use Pre-built Scripts

### Windows
Double-click: `quick_build.bat`

### Mac/Linux
```bash
chmod +x quick_build.sh
./quick_build.sh
```

---

## 📱 After Installation

### Enable Keyboard
1. Open the app
2. Tap "Enable Keyboard"
3. Check "Bangla Keyboard"

### Select as Default
1. Tap "Select Keyboard"
2. Choose "Bangla Keyboard"

### Test It
1. Open WhatsApp
2. Try typing
3. Swipe on spacebar to switch languages!

---

## 🎮 Features to Test

- ✅ English typing
- ✅ Bangla (বাংলা) typing
- ✅ Avro (অভ্র) phonetic typing
- ✅ Swipe spacebar to switch languages
- ✅ Emoji button
- ✅ Clipboard button
- ✅ Settings → Sound
- ✅ Settings → Vibration

---

**That's it! Enjoy your Bangla Keyboard! 🎉**
