@echo off
echo ==========================================
echo   Bangla Keyboard - Quick Build Script
echo ==========================================
echo.

:: Check if Android SDK is installed
if not exist "%LOCALAPPDATA%\Android\Sdk" (
    echo [ERROR] Android SDK not found!
    echo Please install Android Studio first.
    echo Download: https://developer.android.com/studio
    pause
    exit /b 1
)

:: Set environment variables
set ANDROID_SDK_ROOT=%LOCALAPPDATA%\Android\Sdk
set PATH=%PATH%;%ANDROID_SDK_ROOT%\tools;%ANDROID_SDK_ROOT%\platform-tools

echo [INFO] Starting build...
echo.

:: Navigate to project folder
cd /d "%~dp0BanglaKeyboard"

:: Clean previous build
echo [1/4] Cleaning previous build...
call gradlew clean

:: Build debug APK
echo [2/4] Building APK...
call gradlew assembleDebug

:: Check if build successful
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo.
    echo ==========================================
    echo   BUILD SUCCESSFUL! ✅
    echo ==========================================
    echo.
    echo APK Location:
    echo app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo Next steps:
    echo 1. Copy app-debug.apk to your phone
    echo 2. Enable "Unknown Sources" in Settings
    echo 3. Install the APK
    echo.
    start explorer "app\build\outputs\apk\debug"
) else (
    echo.
    echo [ERROR] Build failed!
    echo Please check the error messages above.
)

pause
