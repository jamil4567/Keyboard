#!/bin/bash

echo "=========================================="
echo "   Bangla Keyboard - Quick Build Script"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if Android SDK is installed
if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
    echo -e "${RED}[ERROR] Android SDK not found!${NC}"
    echo "Please install Android Studio first."
    echo "Download: https://developer.android.com/studio"
    exit 1
fi

echo "[INFO] Starting build..."
echo ""

# Navigate to project folder
cd "$(dirname "$0")/BanglaKeyboard" || exit 1

# Clean previous build
echo "[1/4] Cleaning previous build..."
./gradlew clean

# Build debug APK
echo "[2/4] Building APK..."
./gradlew assembleDebug

# Check if build successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo ""
    echo "=========================================="
    echo "   BUILD SUCCESSFUL! ✅"
    echo "=========================================="
    echo ""
    echo "APK Location:"
    echo "app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "Next steps:"
    echo "1. Copy app-debug.apk to your phone"
    echo "2. Enable 'Unknown Sources' in Settings"
    echo "3. Install the APK"
    echo ""
    
    # Open folder (Linux)
    if command -v xdg-open &> /dev/null; then
        xdg-open "app/build/outputs/apk/debug"
    fi
    # Open folder (Mac)
    if command -v open &> /dev/null; then
        open "app/build/outputs/apk/debug"
    fi
else
    echo ""
    echo -e "${RED}[ERROR] Build failed!${NC}"
    echo "Please check the error messages above."
fi

read -p "Press Enter to continue..."
